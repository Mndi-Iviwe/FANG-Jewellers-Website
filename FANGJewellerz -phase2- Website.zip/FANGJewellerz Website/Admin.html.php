<?php
    @include '../Components/Connection.php';
    @include '../Components/alerts.php';

    //Connection string is typed due to location error
    $conn = mysqli_connect('localhost','root','','fangjewellerz_db',3306);

    $product_name = (string)$_POST['product_name'];
    $product_price = (string)$_POST['product_price'];
    $product_image = (string)$_FILES['product_image']['name'];
    $product_image_tmp_name = (string)$_FILES['product_image']['tmp_name'];
    $product_image_folder = 'Product Images/'.$product_image;
 
    if(empty($product_name) || empty($product_price) || empty($product_image)){
       $message[] = 'Please fill out all details';
    }else{
        $insert = "INSERT INTO fangproducts(prodName, prodPrice, prodImage) VALUES('$product_name', '$product_price', '$product_image');";
        $upload = mysqli_query($conn, $insert);
        if($upload){
           move_uploaded_file($product_image_tmp_name, $product_image_folder);
           $message[] = 'New product added successfully';
        }else{
           $message[] = 'Could not add product';
        }
     }

     if(isset($_GET['delete'])){
        $id = $_GET['delete'];
        mysqli_query($conn, "DELETE FROM fangproducts WHERE prod_ID = $id;");
        header('location:Admin.html.php');
     }
  
?>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="Styling/Style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"
     integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A=="
      crossorigin="anonymous" referrerpolicy="no-referrer" /> 
    <title>Admin Product Section</title>
</head>
<body>

<?php
    if(isset($message)){
        foreach($message as $message){
           echo '<span class="message">'.$message.'</span>';
        }
     }
?>
    <header class="nav-header">

                <div class="nav-icon">
                    <img src="Images/fangtastic logo.jpeg" alt="Logo FANGJewlerz" class="circle-logo">
                    <h4 class="company-name">FANGTASTIC</h4>
                </div>

        <div class="nav-div">

            <nav>
            <ul class="nav-links">
                <li><a href="index.php">Homepage</a></li>
                <li><a href="Products.html.php">Products</a></li>
                <li><a href="NewsPage.html.php">News & Updates</a></li>
                <li><a href="ContactUs.html.php">Contact Us</a></li> 
                <li><a href="" id="cartButton"><i class="fa-solid fa-cart-shopping" ></i></a></li>
                <li><a href=""><i class="fa-solid fa-user"></i></a></li>
                </ul>

            </nav>
        </div>

    </header>

    <!------------------------Admin Section------------------------->
    <div class="admin-container">
        <div class="admin-prod-form">
            <form action="<?php $_SERVER['PHP_SELF'] ?>" method="post" enctype="multipart/form-data">
                <h3>Add a New Product</h3>
                <input type="text" placeholder="enter product name" name="product_name" class="box">
                <input type="number" placeholder="enter product price" name="product_price" class="box">
                <input type="file" accept="image/png, image/jpeg, image/jpg" name="product_image" class="box">
                <input type="submit" class="prod-btn" name="add_product" value="Add Product">
            </form>
        </div>
    </div>

    <?php

   $select = mysqli_query($conn, "SELECT * FROM fangproducts;");
   
   ?>
   <div class="product-display">
      <table class="product-display-table">
         <thead>
         <tr>
            <th>product image</th>
            <th>product name</th>
            <th>product price</th>
            <th>action</th>
         </tr>
         </thead>
         <?php while($row = mysqli_fetch_assoc($select)){ ?>
         <tr>
            <td><img src="Product Images/<?php echo $row['prodImage']; ?>" height="100" alt=""></td>
            <td><?php echo $row['prodName']; ?></td>
            <td>$<?php echo $row['prodPrice']; ?>/-</td>
            <td>
               <a href="AdminUpdate.html.php?edit=<?php echo $row['prod_ID']; ?>" class="btn"> <i class="fas fa-edit"></i> edit </a>
               <a href="Admin.html.php?delete=<?php echo $row['prod_ID']; ?>" class="btn"> <i class="fas fa-trash"></i> delete </a>
            </td>
         </tr>
      <?php } ?>
      </table>
   </div>


    <footer>
        <div class="footer-container">
            <div class="social-icons">
                <a href="https://za.pinterest.com/alexandriianyathii26/fangtastic-sa-pinspo/"><i class="fa-brands fa-pinterest"></i></a>
                <a href="https://www.instagram.com/fangtasticsa?utm_source=ig_web_button_share_sheet&igsh=ZDNlZDc0MzIxNw=="><i class="fa-brands fa-instagram"></i></a>
                <a href="https://www.tiktok.com/discover/tooth-gem-fangs"><i class="fa-brands fa-tiktok"></i></a>
            </div>
            <nav>
                <ul class="footer-nav-links">
                <li><a href="HomePage.html">Homepage</a></li>
                <li><a href="Products.html">Products</a></li>
                <li><a href="NewsPage.html">News & Updates</a></li>
                </ul>
            </nav>
            
        </div>
        <div class="footer-credit">
            <p>@Mo Piiercings</p>
            <p>155 Smit Street, Braamfontein</p>
            <p>CopyRight &copy;2024; Designed By <span class="designer">FANGJewellerz</span></p>
        </div>
    </footer>

    <script src="JavaScrypt/Scrypt.js"></script>
</body>
</html>