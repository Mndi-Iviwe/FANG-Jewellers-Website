<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="Styling/Style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"
     integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A=="
      crossorigin="anonymous" referrerpolicy="no-referrer" /> 
    <title>Product HomePage</title>
</head>
<body>
    <header class="nav-header">

                <div class="nav-icon">
                    <img src="Images/fangtastic logo.jpeg" alt="Logo FANGJewlerz" class="circle-logo">
                    <h4 class="company-name">FANGTASTIC</h4>
                </div>

        <div class="nav-div">

            <nav>
            <ul class="nav-links">
                <li><a href="index.php">Homepage</a></li>
                <li><a href="Products.html.php">Products</a></li>
                <li><a href="NewsPage.html.php">News & Updates</a></li>
                <li><a href="ContactUs.html.php">Contact Us</a></li> 
                <li><a href="" id="cartButton"><i class="fa-solid fa-cart-shopping" ></i></a></li>
                <li><a href=""><i class="fa-solid fa-user"></i></a></li>
                </ul>

            </nav>
        </div>

    </header>

    <!----------------Cart Section---------------->
    <div class="modal" id="cartmodal">
        <div class="modal-content">
            <table class="cart-items">
                <tr>
                    <th>Product</th>
                    <th>Quantity</th>
                    <th>Sub-Total</th>
                </tr>
                <tr>
                    <td>
                        <div class="cart-info">
                            <img src="Images/Toothgem-kit.jpg" alt="Tooth Gems Box of tooth gems ">
                            <div>
                                <p>House Tooth Gem Kit</p>
                                <small>Price: R200</small>
                                <br>
                                <a href="">Remove</a>
                            </div>
                        </div>
                    </td>
                    <td><input type="number" value="0"></td>
                    <td>R<span id="subtot-price">200.00</span></td>
                </tr> 
            </table>
            <div class="cart-total">
                <table>
                    <tr>
                        <td>Sub-Total</td>
                        <td>R<span id="subTotal-price">0.00</span></td>
                    </tr>
                    <tr>
                        <td>Delivery Fee</td>
                        <td>R35</td>
                    </tr>
                    <tr>
                        <td>Total Price:</td>
                        <td>R<span id="Total-Price">0.00</td>
                    </tr>
                    <tr>
                        <td ><a href="" id="close-cart">close</a></td>
                    </tr>
                </table>
            </div>
        </div>
</div>

    <footer>
        <div class="footer-container">
            <div class="social-icons">
                <a href="https://za.pinterest.com/alexandriianyathii26/fangtastic-sa-pinspo/"><i class="fa-brands fa-pinterest"></i></a>
                <a href="https://www.instagram.com/fangtasticsa?utm_source=ig_web_button_share_sheet&igsh=ZDNlZDc0MzIxNw=="><i class="fa-brands fa-instagram"></i></a>
                <a href="https://www.tiktok.com/discover/tooth-gem-fangs"><i class="fa-brands fa-tiktok"></i></a>
            </div>
            <nav>
                <ul class="footer-nav-links">
                <li><a href="HomePage.html">Homepage</a></li>
                <li><a href="Products.html">Products</a></li>
                <li><a href="NewsPage.html">News & Updates</a></li>
                </ul>
            </nav>
            
        </div>
        <div class="footer-credit">
            <p>@Mo Piiercings</p>
            <p>155 Smit Street, Braamfontein</p>
            <p>CopyRight &copy;2024; Designed By <span class="designer">FANGJewellerz</span></p>
        </div>
    </footer>

    <script src="JavaScrypt/Scrypt.js"></script>
</body>
</html>