<?php
    @include '../Components/Connection.php';

    if(isset($_POST['submit'])){
        $id = (string)unique_id();
        $fname = (string)$_POST['fname'];
        $sname = (string)$_POST['fname'];
        $email = (string)$_POST['email'];
        $pass = (string)sha1($_POST['password']);
        $cpass = (string)sha1($_POST['confirm']);



        //RETURN TO VALIDATION---------
        $query = "SELECT * FROM 'fanguser'(`user_id`, `fname`, `sname`, `email`, `password`) WHERE email = '$email';";
        $result = $conn->query($query);

        

        if($result > 0){
                $warning_msg[] = 'email already exists!';
            }else{
                if($pass != $cpass){
                    $warning_msg[] = 'confirm password not matched!';
                }else{
                    $insert = "INSERT INTO 'fanguser'(`user_id`, `fname`, `sname`, `email`, `password`) VALUES('$id','$fname','$sname','$email','$cpass');";
                    $insert_cust = mysqli_query($conn,$query);

                    $success_msg[] = 'new customer registered! Please Login now';
                }
            }
    }
?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../Styling/AdminStyle.css">
    <title>Registration Page</title>
</head>
<body>
  

    <div class="form-container">
        <form action="" method="post" class="register">

            <div class="form-flex">
                <h3>Register Now!</h3>
                <div class="form-col">
                    <div class="input-field">
                        <label for="">Your First Name:</label><br>
                        <input type="text" name="fname" required>
                    </div>
                    <div class="input-field">
                        <label for="">Your Last Name:</label><br>
                        <input type="text" name="lname" required class="box">
                    </div>
                    <div class="input-field">
                        <label for="">Your Email:</label><br>
                        <input type="email" name="email" required class="box">
                    </div>
                    <div class="form-col">
                    <div class="input-field">
                        <label for="">Enter Password:</label><br>
                        <input type="password" name="password" required class="box">
                    </div>
                    <div class="input-field">
                        <label for="">Confirm Password</label><br>
                        <input type="password" name="confirm"  required class="box">
                    </div>
                    <p>Already have an account? Then Log-in <a href="Login.php">here.</a> </p>
                    <input type="submit" value="Register" name="submit">
                    </div>
                </div>
            </div>
        </form>
    </div>


    <?php
         include '../Components/alerts.php';
    ?>
    <script src="JavaScrypt/Scrypt.js"></script>
</body>
</html>