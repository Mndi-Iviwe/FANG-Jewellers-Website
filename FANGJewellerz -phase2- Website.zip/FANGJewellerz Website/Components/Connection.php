<?php
    $db_hostname = 'localhost';
    $db_username = 'root';
    $db_password = '';
    $db_dbname = 'fangjewellerz_db';
    $db_port = 3306;

    $conn = mysqli_connect($db_hostname,$db_username,$db_password, $db_dbname, $db_port);
    //$conn = mysqli_connect('localhost','root','','fangjewellerz_db',3306);

    if ($conn){
        echo "connected";
    }else{
        echo "not connected";
    }

    function unique_id(){
        $char = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $char_length = strlen($char);
        $randomstring = '';
        for($i = 0; $i < 20; $i++){
            $randomstring.=$char[mt_rand(0, $char_length - 1)];
        }
        return $randomstring;
    }

    function prod_id(){
        $char = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $char_length = strlen($char);
        $randomstring = '';
        for($i = 0; $i < 10; $i++){
            $randomstring.=$char[mt_rand(0, $char_length - 1)];
        }
        return $randomstring;
    }
?>