let cart = [];
let totalPrice = 0;
const cartButton = document.getElementById("cartButton");
const cartModal = document.getElementById("cartmodal");
const closeButton = document.querySelector("close-cart");

// Show modal when cart button is clicked
cartButton.onclick = function () {
    cartModal.style.display = "block";
};

// Close modal when close button is clicked
closeButton.onclick = function () {
    cartModal.style.display = "none";
};

window.onclick = function (event) {
    if (event.target === cartModal) {
        cartModal.style.display = "none";
    }
};

function addToCart(productName, productPrice) {
    cart.push({ name: productName, price: productPrice });
    totalPrice += productPrice;
    updateCart();
}

function updateCart() {
    const cartItems = document.getElementById('cart-items');
    cartItems.innerHTML = '';
    cart.forEach(item => {
        const tr = document.createElement('tr');
        tr.textContent = `${item.name} - ${item.price.toFixed(2)}`;
        cartItems.appendChild(li);
    });

    document.getElementById('Total-Price').textContent = totalPrice.toFixed(2);
}

function toggleCart() {
    const cartContainer = document.getElementById('cart-container');
    const toggleBtn = document.getElementById('toggle-cart');
    if (cartContainer.classList.contains('collapsed')) {
        cartContainer.classList.remove('collapsed');
        toggleBtn.classList.remove('collapsed');
    } else {
        cartContainer.classList.add('collapsed');
        toggleBtn.classList.add('collapsed');
    }
}


