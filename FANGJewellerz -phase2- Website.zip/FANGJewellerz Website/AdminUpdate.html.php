<?php

@include 'Connection.php';

//Connection string is typed due to location error
$conn = mysqli_connect('localhost','root','','fangjewellerz_db',3306);

$id = $_GET['edit'];

if(isset($_POST['update_product'])){

   $product_name = $_POST['product_name'];
   $product_price = $_POST['product_price'];
   $product_image = $_FILES['product_image']['name'];
   $product_image_tmp_name = $_FILES['product_image']['tmp_name'];
   $product_image_folder = 'Product Images/'.$product_image;

   if(empty($product_name) || empty($product_price) || empty($product_image)){
      $message[] = 'please fill out all necessarry details!';    
   }else{

      $update_data = "UPDATE fangproducts SET prodName='$product_name', prodPrice='$product_price', prodImage='$product_image'  WHERE prod_ID = '$id'";
      $upload = mysqli_query($conn, $update_data);

      if($upload){
         move_uploaded_file($product_image_tmp_name, $product_image_folder);
         header('location:Admin.html.php');
      }else{
         $message[] = 'please fill out all details!'; 
      }

   }
};

?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="Styling/Style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"
     integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A=="
      crossorigin="anonymous" referrerpolicy="no-referrer" /> 
    <title>Admin Update</title>
</head>
<body>
    
<?php
   if(isset($message)){
      foreach($message as $message){
         echo '<span class="message">'.$message.'</span>';
      }
   }
?>

   <header class="nav-header">

                <div class="nav-icon">
                    <img src="Images/fangtastic logo.jpeg" alt="Logo FANGJewlerz" class="circle-logo">
                    <h4 class="company-name">FANGTASTIC</h4>
                </div>

        <div class="nav-div">

            <nav>
            <ul class="nav-links">
                <li><a href="index.php">Homepage</a></li>
                <li><a href="Products.html.php">Products</a></li>
                <li><a href="NewsPage.html.php">News & Updates</a></li>
                <li><a href="ContactUs.html.php">Contact Us</a></li> 
                <li><a href="" id="cartButton"><i class="fa-solid fa-cart-shopping" ></i></a></li>
                <li><a href=""><i class="fa-solid fa-user"></i></a></li>
                </ul>

            </nav>
        </div>

    </header>

    <div class="admin-container">


<div class="admin-prod-form centered">

   <?php
      
      $select = mysqli_query($conn, "SELECT * FROM fangproducts WHERE prod_ID = '$id';");
      while($row = mysqli_fetch_assoc($select)){

   ?>
   
    <form action="<?php $_SERVER['PHP_SELF'] ?>" method="post" enctype="multipart/form-data">
      <h3 class="title">update the product</h3>
      <input type="text" class="box" name="product_name" value="<?php echo $row['prodName']; ?>" placeholder="enter the product name">
      <input type="number" min="0" class="box" name="product_price" value="<?php echo $row['prodPrice']; ?>" placeholder="enter the product price">
      <input type="file" class="box" name="product_image"  accept="image/png, image/jpeg, image/jpg">
      <input type="submit" value="Update Product" name="update_product" class="prod_btn">
      <a href="Admin.html.php" class="prod-btn">Nevermind, Back!</a>
    </form>
   


   <?php }; ?>

   

</div>

</div>



    <script src="JavaScrypt/Scrypt.js"></script>
</body>
</html>