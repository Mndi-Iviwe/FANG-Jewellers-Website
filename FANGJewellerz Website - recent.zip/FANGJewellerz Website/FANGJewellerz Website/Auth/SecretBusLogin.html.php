<?php
@include '../Components/connection.php';
@include '../Components/alerts.php';


if(isset($_POST['adminsubmit'])){

    $email = mysqli_real_escape_string($conn, $_POST['a_email']);
    $pass = md5($_POST['a_password']);


    $adminselect = " SELECT * FROM fangadmin WHERE adminEmail = '$email' && adminPassword = '$pass';";
 
    $adminresult = mysqli_query($conn, $adminselect);
 
    //prepare 2 sql queries and connections here, one for fanguser and the other for fangadmin
      $adminlogin = $conn -> prepare(" SELECT * FROM fangadmin WHERE adminEmail = ? && adminPassword = ?;");
      $adminlogin -> bind_param("ss",$email,$pass);
      $adminlogin -> execute();

    if($adminlogin -> execute()){
         $adminlogin -> close();
         session_start();
         $_SESSION["admin_user"] = $email;
         header('location:../Admin.html.php');
      
    }else{
       $error[] = 'incorrect email or password!';
    }
 
 
 
 }

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>login form</title>

   <!-- custom css file link  -->
   <link rel="stylesheet" href="../Styling/AuthStyle.css">

</head>
<body>
<div class="form-container">

   <form action="" method="post">
      <h3>Admin Log-In</h3>
      <input type="email" name="a_email" required placeholder="enter your email">
      <input type="password" name="a_password" required placeholder="enter your password">

      <input type="submit" name="adminsubmit" value="login now" class="form-btn">
   </form>

</div>

</body>
</html>