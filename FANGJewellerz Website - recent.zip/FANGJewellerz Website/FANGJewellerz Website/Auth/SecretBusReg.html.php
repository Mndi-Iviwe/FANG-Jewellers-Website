<?php

@include '../Components/connection.php';
@include '../Components/alerts.php';


if(isset($_POST['submit'])){

   $fname = mysqli_real_escape_string($conn, $_POST['fname']);
   $lname = mysqli_real_escape_string($conn, $_POST['lname']);
   $email = mysqli_real_escape_string($conn, $_POST['email']);
   $pass = md5($_POST['password']);
   $cpass = md5($_POST['cpassword']);
   $Code = mysqli_real_escape_string($conn, $_POST['adminCode']); 



// I think i can use the prepare method here
   $adminselect = " SELECT * FROM fangadmin WHERE adminEmail = '$email' && adminPassword = '$pass';";
   $adminresult = mysqli_query($conn, $adminselect);


   if($_POST['adminCode'] == $adminKey && mysqli_num_rows($adminresult) == 0){

      $admininsert = $conn -> prepare("INSERT INTO fangadmin VALUES(NULL,?,?,?,?);");
      $admininsert -> bind_param("ssss",$fname,$lname,$email,$cpass);

      $lname = "Admin";
      if($pass != $cpass){
         $error[] = 'password not matched!';
      }elseif(mysqli_num_rows($adminresult) > 0){
         $error[] = 'Admin Already Exists';
      }else{
         $admininsert -> execute();
         $admininsert -> close();
         header('location:SecretBusLogin.html.php');
      }
   

}
}


?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>register form</title>

   <!-- custom css file link  -->
   <link rel="stylesheet" href="../Styling/AuthStyle.css">

</head>
<body>
   
<div class="form-container">

   <form action="" method="post">
      <h3>register now</h3>
      <?php
      if(isset($error)){
         foreach($error as $error){
            echo '<span class="error-msg">'.$error.'</span>';
         };
      };
      ?>
      <input type="text" name="fname" required placeholder="enter your name">
      <input type="text" name="lname" required placeholder="enter your last name">
      <input type="email" name="email" required placeholder="enter your email">
      <input type="password" name="password" required placeholder="enter your password">
      <input type="password" name="cpassword" required placeholder="confirm your password">
      <label for="">note: This is only for admins!!!</label>
      <input type="text" name="adminCode" placeholder="(xxxxxxx-Enter Code-xxxxxxx)" require>
      <input type="submit" name="submit" value="register now" class="form-btn">
      <p>already an Administrator? <a href=".html.php">Prove It Here!</a></p>
   </form>

</div>

</body>
</html>