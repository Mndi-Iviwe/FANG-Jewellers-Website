<?php
    include '../Components/Connection.php';

    if(isset($_POST['submit'])){

        $email = $_POST['email'];

        $pass = sha1($_POST['password']);

        $query = "SELECT * FROM fangusers WHERE email = '$email' AND password ='$pass';";
        $select_cust = mysqli_query($conn, $query);
        $result = $conn->query($query);

        if($result > 0){
           setcookie('User', $row['fname'], time() + 60*60*24*30, "/");
           header('location:index.php'); 
        }else{
            $warning_msg[] = 'incorrect email or password';
        }
    }
?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../Styling/AdminStyle.css">
    <title>Registration Page</title>
</head>
<body>
  

    <div class="form-container">
        <form action="" method="post" class="register">

            <div class="form-flex">
                <h3>Log-In </h3>
                <div class="form-col">
                    <div class="input-field">
                        <label for="">Your Email:</label><br>
                        <input type="email" name="email" required class="box">
                    </div>
                    <div class="input-field">
                        <label for="">Enter Password:</label><br>
                        <input type="password" name="password" required class="box">
                    </div>
                    <p>Do not have an account? Then Register <a href="Register.php">here.</a> </p>
                    <input type="submit" value="Log-In" name="submit">
                </div>
            </div>
        </form>
    </div>


    <?php
         include '../Components/alerts.php';
    ?>
    <script src="JavaScrypt/Scrypt.js"></script>
</body>
</html>