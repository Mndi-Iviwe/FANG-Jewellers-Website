<?php

session_start();

@include 'Components/connection.php';
@include 'Components/alerts.php';

//$conn = mysqli_connect('localhost','root','','fangjewellerz_db',3306);


?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="Styling/Style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"
     integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A=="
      crossorigin="anonymous" referrerpolicy="no-referrer" />
    <title>Web Index</title>
</head>
<body>
<header class="nav-header">

                <div class="nav-icon">
                    <img src="Images/fangtastic logo.jpeg" alt="Logo FANGJewlerz" class="circle-logo">
                    <h4 class="company-name">FANGTASTIC™</h4>
                </div>

        <div class="nav-div">

            <nav>
            <ul class="nav-links">
                <li><a href="index.php">Homepage</a></li>
                <li><a href="Products.html.php">Products</a></li>
                <li><a href="NewsPage.html.php">News & Updates</a></li>
                <li><a href="ContactUs.html.php">Contact Us</a></li> 

                </ul>
            </nav>
            <?php
                $select_rows = mysqli_query($conn, "SELECT * FROM fangcart;");
                $row_count = mysqli_num_rows($select_rows);
            ?>

            <a href="Cart.html.php" id="cartButton"><i class="fa-solid fa-cart-shopping" ></i><span><?php echo $row_count; ?></span></a>

            <?php if (!isset($_SESSION["user_name"]) || $_SESSION["user_name"] == "guest") {
                    echo "
                    <a href='../FANGJewellerz Website/Auth/LoginForm.html.php' id='userButton'><i class='fa-solid fa-user'></i></a>
                    ";
                }else{
                    echo $_SESSION["user_name"];
                    echo "<a href='../FANGJewellerz Website/Components/logout.php' id='logoutbtn'><i class='fa-solid fa-right-from-bracket'></i></a>";
                }
            ?>
        </div>

</header>
<div class="user-container">
      <div class="content">
         <h3>hi, </h3>
            <h1>welcome, 
                <span> <?php if (!isset($_SESSION["user_name"])) {
                    $_SESSION["user_name"] = "guest";
                }else{
                    echo $_SESSION["user_name"];
                }?></span>;
            </h1>
      </div>
</div>
<div class="contact-us">
    <h2 class="heading">Contact Us</h2>

    <form action="/submit-contact" method="POST">
        <div class="inputBox">
            <label for="name">Name:</label>
            <input type="text" id="name" name="name" required>
        </div>

        <div class="inputBox">
            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required>
        </div>


        <div class="inputBox">
            <label for="subject">Subject:</label>
            <input type="text" id="subject" name="subject" required>
        </div>


        <div class="inputBox">
            <label for="message">Message:</label>
            <textarea id="message" name="message" rows="6" required></textarea>
        </div>


        <input type="submit" value="Submit" class="btn" name="querySubmit">
    </form>

</div>






    <footer>
        <div class="footer-container">
            <div class="social-icons">
                <a href="https://za.pinterest.com/alexandriianyathii26/fangtastic-sa-pinspo/"><i class="fa-brands fa-pinterest"></i></a>
                <a href="https://www.instagram.com/fangtasticsa?utm_source=ig_web_button_share_sheet&igsh=ZDNlZDc0MzIxNw=="><i class="fa-brands fa-instagram"></i></a>
                <a href="https://www.tiktok.com/discover/tooth-gem-fangs"><i class="fa-brands fa-tiktok"></i></a>
            </div>
            <nav>
                <ul class="footer-nav-links">
                <li><a href="Index.html.php">Homepage</a></li>
                <li><a href="Products.html.php">Products</a></li>
                <li><a href="NewsPage.html.php">News & Updates</a></li>
                </ul>
            </nav>
            
        </div>
        <div class="footer-credit">
            <p>@Mo Piiercings</p>
            <p>155 Smit Street, Braamfontein</p>
            <p>CopyRight &copy;2024; Designed By <span class="designer">FANGJewellerz</span></p>
        </div>
    </footer>

    <script src="JavaScrypt/Scrypt.js"></script>
</body>
</html>