<?php

@include '../Components/connection.php';
@include '../Components/alerts.php';

session_start();
session_unset();
session_destroy();

header('location:../Index.php');

?>