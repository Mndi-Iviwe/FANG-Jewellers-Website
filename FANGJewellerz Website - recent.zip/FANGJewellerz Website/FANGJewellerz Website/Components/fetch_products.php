<?php
@include '../Components/connection.php';

// Enable error reporting to troubleshoot issues during development (disable in production)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Start output buffering to ensure no output before JSON
ob_start();

$select_prices = mysqli_query($conn, "SELECT * FROM fangprices;");
$prices = array();

if (mysqli_num_rows($select_prices) > 0) {
    while ($row = mysqli_fetch_assoc($select_prices)) {
        $prices[] = array(
            'item_name' => $row['item_name'],
            'item_price' => $row['item_price']
        );
    }
}

header('Content-Type: application/json');
echo json_encode($prices);

// Flush output buffer to prevent any accidental whitespace before JSON
ob_end_flush();
?>

