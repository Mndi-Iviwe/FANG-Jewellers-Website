<?php
@include '../Components/connection.php';

// Enable error reporting to troubleshoot issues during development (disable in production)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Start output buffering to ensure no output before JSON
ob_start();

$select_products = mysqli_query($conn, "SELECT * FROM fangproducts;");
$products = array();

if (mysqli_num_rows($select_products) > 0) {
    while ($row = mysqli_fetch_assoc($select_products)) {
        $products[] = array(
            'prod_ID' => $row['prod_ID'],
            'prodName' => $row['prodName'],
            'prodPrice' => $row['prodPrice'],
            'prodImage' => $row['prodImage'],
        );
    }
}

header('Content-Type: application/json');
echo json_encode($products);

// Flush output buffer to prevent any accidental whitespace before JSON
ob_end_flush();
?>
