<?php
session_start();

@include 'Components/connection.php';
@include 'Components/alerts.php';

//$conn = mysqli_connect('localhost','root','','fangjewellerz_db',3306);

if(isset($_POST['update_update_btn'])){
   $update_value = $_POST['update_quantity'];
   $update_id = $_POST['update_quantity_id'];


   $quant_update = $conn->prepare("UPDATE fangcart SET fangcart.c_prodquant = ? WHERE fangcart.cart_ID = ?;");

   $quant_update -> bind_param("ii",$update_value,$update_id);

   $quant_update->execute();

   if($quant_update ->execute()){
      $quant_update->close();
      header('location:Cart.html.php');
      $message[] = "Product quantity updated!!!";
   }else{
      $quant_update->close();
      header('location:Cart.html.php');
      $message[] = "Failed to update product quantity ";
   }

};

if(isset($_GET['remove'])){
   $remove_id = $_GET['remove'];
   mysqli_query($conn, "DELETE FROM fangcart WHERE cart_ID = '$remove_id';");
   header('location:cart.html.php');
};

if(isset($_GET['delete_all'])){
   mysqli_query($conn, "DELETE FROM fangcart;");
   header('location:cart.html.php');
}

?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="Styling/Style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"
     integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A=="
      crossorigin="anonymous" referrerpolicy="no-referrer" /> 
    <title>Product HomePage</title>
</head>
<body>
<?php

if(isset($message)){
   foreach($message as $message){
      echo '<div class="message"><span>'.$message.'</span> <i class="fas fa-times" onclick="this.parentElement.style.display = `none`;"></i> </div>';
   }
}

?>
<header class="nav-header">

<div class="nav-icon">
    <img src="Images/fangtastic logo.jpeg" alt="Logo FANGJewlerz" class="circle-logo">
    <h4 class="company-name">FANGTASTIC™</h4>
</div>

<div class="nav-div">

<nav>
<ul class="nav-links">
<li><a href="index.php">Homepage</a></li>
<li><a href="Products.html.php">Products</a></li>
<li><a href="NewsPage.html.php">News & Updates</a></li>
<li><a href="ContactUs.html.php">Contact Us</a></li> 

</ul>
</nav>
<?php
$select_rows = mysqli_query($conn, "SELECT * FROM fangcart;");
$row_count = mysqli_num_rows($select_rows);
?>

<a href="Cart.html.php" id="cartButton"><i class="fa-solid fa-cart-shopping" ></i><span><?php echo $row_count; ?></span></a>

<?php if (!isset($_SESSION["user_name"]) || $_SESSION["user_name"] == "guest") {
                    echo "
                    <a href='../FANGJewellerz Website/Auth/LoginForm.html.php' id='userButton'><i class='fa-solid fa-user'></i></a>
                    ";
                }else{
                    echo $_SESSION["user_name"];
                    echo "<a href='../FANGJewellerz Website/Components/logout.php' id='logoutbtn'><i class='fa-solid fa-right-from-bracket'></i></a>";
                }
            ?>
</div>

</header>
<div class="user-container">
      <div class="content">
         <h3>hi, </h3>
            <h1>welcome, 
                <span> <?php if (!isset($_SESSION["user_name"])) {
                    $_SESSION["user_name"] = "guest";
                }else{
                    echo $_SESSION["user_name"];
                }?></span>;
            </h1>
      </div>
</div>
    <!----------------Cart Section---------------->
    <div class="cart-container">

<section class="shopping-cart">

   <h1 class="heading">Shopping cart</h1>

   <table>

      <thead>
         <th>Image</th>
         <th>Name</th>
         <th>Price</th>
         <th>Quantity</th>
         <th>Total Price</th>
         <th>Action</th>
      </thead>

      <tbody>

         <?php 
         
         $select_cart = mysqli_query($conn, "SELECT * FROM fangcart;");
         $grand_total = 0;
         if(mysqli_num_rows($select_cart) > 0){
            while($fetch_cart = mysqli_fetch_assoc($select_cart)){
         ?>

         <tr>
            <td><img src="Product Images/<?php echo $fetch_cart['c_prodimage']; ?>" height="100" alt=""></td>
            <td><?php echo $fetch_cart['c_prodname']; ?></td>
            <td>R<?php echo number_format($fetch_cart['c_prodprice']); ?>/-</td>
            <td>
               <form action="" method="post">
                  <input type="hidden" name="update_quantity_id"  value="<?php echo $fetch_cart['cart_ID']; ?>" >
                  <input type="number" name="update_quantity" min="1"  value="<?php echo $fetch_cart['c_prodquant']; ?>" >
                  <input type="submit" value="update" name="update_update_btn">
               </form>   
            </td>
            <td>R<?php echo $sub_total = number_format($fetch_cart['c_prodprice'] * $fetch_cart['c_prodquant']); ?>/-</td>
            <td><a href="cart.html.php?remove=<?php echo $fetch_cart['cart_ID']; ?>" onclick="return confirm('remove item from cart?')" class="delete-btn"> <i class="fas fa-trash"></i> remove</a></td>
         </tr>
         <?php
           $grand_total += $sub_total;  
            };
         };
         ?>
         <tr class="table-bottom">
            <td><a href="Products.html.php" class="option-btn" style="margin-top: 0;">continue shopping</a></td>
            <td colspan="3">grand total</td>
            <td>R<?php echo $grand_total; ?>/-</td>
            <td><a href="cart.html.php?delete_all" onclick="return confirm('are you sure you want to delete all?');" class="delete-btn"> <i class="fas fa-trash"></i> delete all </a></td>
         </tr>

      </tbody>

   </table>

   <div class="checkout-btn">
      <?php 
         if($_SESSION["user_name"] == null){
               echo "please login to proceed to checkout";
               $message[] = "please login to proceed to checkout";
         }
      ?>
      <a href="Checkout.html.php" class="btn (.$grand_total > 1)?'':'disabled'; ?>">procced to checkout</a>
   </div>

</section>

</div>

    <!--------------------------------->

    <footer>
        <div class="footer-container">
            <div class="social-icons">
                <a href="https://za.pinterest.com/alexandriianyathii26/fangtastic-sa-pinspo/"><i class="fa-brands fa-pinterest"></i></a>
                <a href="https://www.instagram.com/fangtasticsa?utm_source=ig_web_button_share_sheet&igsh=ZDNlZDc0MzIxNw=="><i class="fa-brands fa-instagram"></i></a>
                <a href="https://www.tiktok.com/discover/tooth-gem-fangs"><i class="fa-brands fa-tiktok"></i></a>
            </div>
            <nav>
                <ul class="footer-nav-links">
                <li><a href="Index.html.php">Homepage</a></li>
                <li><a href="Products.html.php">Products</a></li>
                <li><a href="NewsPage.html.php">News & Updates</a></li>
                </ul>
            </nav>
            
        </div>
        <div class="footer-credit">
            <p>@Mo Piiercings</p>
            <p>155 Smit Street, Braamfontein</p>
            <p>CopyRight &copy;2024; Designed By <span class="designer">FANGJewellerz</span></p>
        </div>
    </footer>

    <script src="JavaScrypt/Scrypt.js"></script>
</body>
</html>