<?php
    session_start();

@include 'Components/connection.php';
@include 'Components/alerts.php';

//$conn = mysqli_connect('localhost','root','','fangjewellerz_db',3306);

if(isset($_POST['add_to_cart'])){

   $product_name = $_POST['product_name'];
   $product_price = $_POST['product_price'];
   $product_image = $_POST['product_image'];
   $product_quantity = 1;

   $select_cart = mysqli_query($conn, "SELECT * FROM fangcart WHERE c_prodname = '$product_name';");

   $cartadd = $conn->prepare("INSERT INTO fangcart(c_prodname, c_prodprice, c_prodimage, c_prodquant) VALUES(?,?,?,?);");
   $cartadd -> bind_param("sdsi", $product_name, $product_price, $product_image, $product_quantity);

   if(mysqli_num_rows($select_cart) > 0){
      $message[] = 'product already added to cart';
   }else{
        $cartadd->execute();
        $cartadd->close();
        $message[] = 'product added to cart succesfully';
   }

}

?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="Styling/Style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"
     integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A=="
      crossorigin="anonymous" referrerpolicy="no-referrer" /> 
    <title>Product HomePage</title>
</head>
<body>
<?php

if(isset($message)){
   foreach($message as $message){
      echo '<div class="message"><span>'.$message.'</span> <i class="fas fa-times" onclick="this.parentElement.style.display = `none`;"></i> </div>';
   }
}

?>
<header class="nav-header">

<div class="nav-icon">
    <img src="Images/fangtastic logo.jpeg" alt="Logo FANGJewlerz" class="circle-logo">
    <h4 class="company-name">FANGTASTIC™</h4>
</div>

<div class="nav-div">

<nav>
<ul class="nav-links">
<li><a href="index.php">Homepage</a></li>
<li><a href="Products.html.php">Products</a></li>
<li><a href="NewsPage.html.php">News & Updates</a></li>
<li><a href="ContactUs.html.php">Contact Us</a></li> 

</ul>
</nav>
<?php
$select_rows = mysqli_query($conn, "SELECT * FROM fangcart;");
$row_count = mysqli_num_rows($select_rows);
?>

<a href="Cart.html.php" id="cartButton"><i class="fa-solid fa-cart-shopping" ></i><span><?php echo $row_count; ?></span></a>

<?php if (!isset($_SESSION["user_name"]) || $_SESSION["user_name"] == "guest") {
                    echo "
                    <a href='../FANGJewellerz Website/Auth/LoginForm.html.php' id='userButton'><i class='fa-solid fa-user'></i></a>
                    ";
                }else{
                    echo $_SESSION["user_name"];
                    echo "<a href='../FANGJewellerz Website/Components/logout.php' id='logoutbtn'><i class='fa-solid fa-right-from-bracket'></i></a>";
                }
            ?>
</div>

</header>
<div class="user-container">
      <div class="content">
         <h3>hi, </h3>
            <h1>welcome, 
                <span> <?php if (!isset($_SESSION["user_name"])) {
                    $_SESSION["user_name"] = "guest";
                }else{
                    echo $_SESSION["user_name"];
                }?></span>;
            </h1>
      </div>
</div>
    <section class="store-prices" >
        <div class="price-header">
            <h1 class="heading">Selection & Prices</h1>
        </div>
        
        <div>
         
            <table class="price-container">

            <thead class="item_table_head">
                <th>Item Name</th>
                <th>Item Price</th>
            </thead>

            <tbody>
         <?php
         
            $select_products = mysqli_query($conn, "SELECT * FROM fangprices;");
            if(mysqli_num_rows($select_products) > 0){
               while($row = mysqli_fetch_assoc($select_products)){
         ?>

         <tr>
            <td><?php echo $row['item_name']; ?></td>
            <td>R<?php echo $row['item_price']; ?></td>
         </tr>

         <?php
            };    
            }else{
               echo "<div class='empty'>no product added</div>";
            }; 
         ?>
      </tbody>
            </table>
            
    
        </div>

           
        
    </section>


 <!---------------User Cart Section---------------->  
 <div class="prod-container">
 <section class="products">

    <h1 class="heading">latest products</h1>

    <div class="box-container">

   <?php
   
   $select_products = mysqli_query($conn, "SELECT * FROM fangproducts;");
   if(mysqli_num_rows($select_products) > 0){
      while($fetch_product = mysqli_fetch_assoc($select_products)){
   ?>

   <form action="" method="post">
      <div class="box">
         <img src="Product Images/<?php echo $fetch_product['prodImage']; ?>" alt="">
         <h3><?php echo $fetch_product['prodName']; ?></h3>
         <div class="price">R<?php echo $fetch_product['prodPrice']; ?>/-</div>
         <input type="hidden" name="product_name" value="<?php echo $fetch_product['prodName']; ?>">
         <input type="hidden" name="product_price" value="<?php echo $fetch_product['prodPrice']; ?>">
         <input type="hidden" name="product_image" value="<?php echo $fetch_product['prodImage']; ?>">
         <input type="submit" class="btn" value="Add to Cart" name="add_to_cart">
      </div>
   </form>

   <?php
      };
   };
   ?>

</div>

</section>

</div>
 <!-------------------->


    <section class="prod-inspo" style="background-color: lightpink;">
        <h2 class="heading"><u>Styles for Inspiration</u></h2>
        <div class="image-row">
            <img src="Images/prices_1.jpg" alt="Image 1">
            <img src="Images/prices_2.jpg" alt="Image 2">
        </div>
    </section>


    <footer>
        <div class="footer-container">
            <div class="social-icons">
                <a href="https://za.pinterest.com/alexandriianyathii26/fangtastic-sa-pinspo/"><i class="fa-brands fa-pinterest"></i></a>
                <a href="https://www.instagram.com/fangtasticsa?utm_source=ig_web_button_share_sheet&igsh=ZDNlZDc0MzIxNw=="><i class="fa-brands fa-instagram"></i></a>
                <a href="https://www.tiktok.com/discover/tooth-gem-fangs"><i class="fa-brands fa-tiktok"></i></a>
            </div>
            <nav>
                <ul class="footer-nav-links">
                <li><a href="Index.html.php">Homepage</a></li>
                <li><a href="Products.html.php">Products</a></li>
                <li><a href="NewsPage.html.php">News & Updates</a></li>
                </ul>
            </nav>
            
        </div>
        <div class="footer-credit">
            <p>@Mo Piiercings</p>
            <p>155 Smit Street, Braamfontein</p>
            <p>CopyRight &copy;2024; Designed By <span class="designer">FANGJewellerz</span></p>
        </div>
    </footer>

    <script src="JavaScrypt/Scrypt.js"></script>
</body>
</html>