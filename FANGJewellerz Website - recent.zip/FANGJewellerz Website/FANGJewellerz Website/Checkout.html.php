<?php
session_start();

@include 'connection.php';
@include 'alerts.php';
$conn = mysqli_connect('localhost','root','','fangjewellerz_db',3306);

if(isset($_POST['order_btn'])){

    $name = $_POST['name'];
    $number = $_POST['number'];
    $email = $_POST['email'];
    $method = $_POST['method'];
    $flat = $_POST['flat'];
    $street = $_POST['street'];
    $city = $_POST['city'];
    $province = $_POST['province'];

 
    $cart_query = mysqli_query($conn, "SELECT * FROM fangcart;");
    $price_total = 0;
    if(mysqli_num_rows($cart_query) > 0){
       while($product_item = mysqli_fetch_assoc($cart_query)){
          $product_name[] = $product_item['c_prodname'] .' ('. $product_item['c_prodquant'] .') ';
          $product_price = number_format($product_item['c_prodprice'] * $product_item['c_prodquant']);
          $price_total += $product_price;
       };
    };
 
    $total_product = implode(', ',$product_name);
    $detail_query = mysqli_query($conn, "INSERT INTO fangorder(ord_prodname,ord_contact,ord_email,ord_method,ord_flat,ord_street,ord_province,ord_city,ord_totprods,ord_totprice) VALUES('$name','$number','$email','$method','$flat','$street','$city','$province','$total_product','$price_total');");
 


    if($cart_query && $detail_query){
       echo "
       <div class='order-message-container'>
       <div class='message-container'>
          <h3>thank you for shopping!</h3>
          <div class='order-detail'>
             <span>".$total_product."</span>
             <span class='total'> total : $".$price_total."/-  </span>
          </div>
          <div class='customer-details'>
             <p> your name : <span>".$name."</span> </p>
             <p> your number : <span>".$number."</span> </p>
             <p> your email : <span>".$email."</span> </p>
             <p> your address : <span>".$flat.", ".$street.", ".$city.", ".$province."</span> </p>
             <p> your payment mode : <span>".$method."</span> </p>
             <p>(*pay when product arrives*)</p>
          </div>
             <a href='Products.html.php' class='btn'>continue shopping</a>
          </div>
       </div>
       ";
    }
 
 }

?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="Styling/Style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"
     integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A=="
      crossorigin="anonymous" referrerpolicy="no-referrer" />
    <title>Checkout Page</title>
</head>
<body>
<header class="nav-header">

                <div class="nav-icon">
                    <img src="Images/fangtastic logo.jpeg" alt="Logo FANGJewlerz" class="circle-logo">
                    <h4 class="company-name">FANGTASTIC™</h4>
                </div>

        <div class="nav-div">

            <nav>
            <ul class="nav-links">
                <li><a href="index.php">Homepage</a></li>
                <li><a href="Products.html.php">Products</a></li>
                <li><a href="NewsPage.html.php">News & Updates</a></li>
                <li><a href="ContactUs.html.php">Contact Us</a></li> 

                </ul>
            </nav>
            <?php
                $select_rows = mysqli_query($conn, "SELECT * FROM fangcart;");
                $row_count = mysqli_num_rows($select_rows);
            ?>

            <a href="Cart.html.php" id="cartButton"><i class="fa-solid fa-cart-shopping" ></i><span><?php echo $row_count; ?></span></a>

            <?php if (!isset($_SESSION["user_name"]) || $_SESSION["user_name"] == "guest") {
                    echo "
                    <a href='../FANGJewellerz Website/Auth/LoginForm.html.php' id='userButton'><i class='fa-solid fa-user'></i></a>
                    ";
                }else{
                    echo $_SESSION["user_name"];
                    echo "<a href='../FANGJewellerz Website/Components/logout.php' id='logoutbtn'><i class='fa-solid fa-right-from-bracket'></i></a>";
                }
            ?>
        </div>

</header>
   
<div class="check-container">

<section class="checkout-form">

   <h1 class="heading">complete your order</h1>

   <form action="" method="post">

   <div class="display-order">
      <?php
         $select_cart = mysqli_query($conn, "SELECT * FROM fangcart;");
         $total = 0;
         $grand_total = 0;
         if(mysqli_num_rows($select_cart) > 0){
            while($fetch_cart = mysqli_fetch_assoc($select_cart)){
            $total_price = number_format($fetch_cart['c_prodprice'] * $fetch_cart['c_prodquant']);
            $grand_total = $total += $total_price;
      ?>
      <span><?= $fetch_cart['c_prodname']; ?>(<?= $fetch_cart['c_prodquant']; ?>)</span>
      <?php
         }
      }else{
         echo "<div class='display-order'><span>your cart is empty!</span></div>";
      }
      ?>
      <span class="grand-total"> grand total : R<?= $grand_total; ?>/- </span>
   </div>

      <div class="flex">
         <div class="inputBox">
            <span>your name</span>
            <input type="text" placeholder="enter your name" name="name" required>
         </div>
         <div class="inputBox">
            <span>your number</span>
            <input type="text" placeholder="enter your number" name="number" required>
         </div>
         <div class="inputBox">
            <span>your email</span>
            <input type="email" placeholder="enter your email" name="email" required>
         </div>
         <div class="inputBox">
            <span>payment method</span>
            <select name="method">
               <option value="cash on delivery" selected>cash on delivery</option>
               <option value="credit cart">credit cart</option>
               <option value="paypal">paypal</option>
            </select>
         </div>
         <div class="inputBox">
            <span>address line 1</span>
            <input type="text" placeholder="e.g. flat no." name="flat" required>
         </div>
         <div class="inputBox">
            <span>address line 2</span>
            <input type="text" placeholder="e.g. street name" name="street" required>
         </div>
         <div class="inputBox">
            <span>city</span>
            <input type="text" placeholder="e.g. Johannesburg" name="city" required>
         </div>
         <div class="inputBox">
            <span>Province</span>
            <input type="text" placeholder="e.g. Gauteng" name="province" required>
         </div>

      <input type="submit" value="Order Now" name="order_btn" class="btn">
   </form>

</section>

</div>







    <footer>
        <div class="footer-container">
            <div class="social-icons">
                <a href="https://za.pinterest.com/alexandriianyathii26/fangtastic-sa-pinspo/"><i class="fa-brands fa-pinterest"></i></a>
                <a href="https://www.instagram.com/fangtasticsa?utm_source=ig_web_button_share_sheet&igsh=ZDNlZDc0MzIxNw=="><i class="fa-brands fa-instagram"></i></a>
                <a href="https://www.tiktok.com/discover/tooth-gem-fangs"><i class="fa-brands fa-tiktok"></i></a>
            </div>
            <nav>
                <ul class="footer-nav-links">
                <li><a href="HomePage.html">Homepage</a></li>
                <li><a href="Products.html">Products</a></li>
                <li><a href="NewsPage.html">News & Updates</a></li>
                </ul>
            </nav>
            
        </div>
        <div class="footer-credit">
            <p>@Mo Piiercings</p>
            <p>155 Smit Street, Braamfontein</p>
            <p>CopyRight &copy;2024; Designed By <span class="designer">FANGJewellerz</span></p>
        </div>
    </footer>

    <script src="JavaScrypt/Scrypt.js"></script>
</body>
</html>