<?php
session_start();

@include 'Components/connection.php';
@include 'Components/alerts.php';


    if(isset($_POST['add_product'])){
    $product_name = (string)$_POST['product_name'];
    $product_price = (string)$_POST['product_price'];

 
    if(empty($product_name) || empty($product_price)){
       $message[] = 'Please fill out All details';
    }else{
            $istmt = $conn->prepare("INSERT INTO fangprices (item_name, item_price) VALUES (?, ?);");
            // Bind parameters (string, double?, string)
            $istmt->bind_param("sd", $product_name, $product_price);
            //$istmt->execute();
            // Close the statement
        if($istmt->execute()){
            $istmt->close();
           $message[] = 'New Item added successfully';
        }else{
           $message[] = 'Could not add Item';
        }
     }
   }

     

     if(isset($_GET['delete'])){
      $delete_id = $_GET['delete'];

      $dltstmt = $conn->prepare("DELETE FROM fangprices WHERE fangprices.item_ID = ?");

      // Bind the parameter (assuming $id is an integer)
      $dltstmt->bind_param("i", $delete_id);

      // Execute the statement
      if($dltstmt->execute()){
         header('location:AdminPricing.html.php');
         $message[] = 'product has been deleted';
      }else{
         header('location:AdminPricing.html.php');
         $message[] = 'product could not be deleted';
      }

      // Close the statement
      $stmt->close();
   }

   if(isset($_POST['update_product'])){
      $update_p_id = $_POST['update_p_id'];
      $update_p_name = $_POST['update_p_name'];
      $update_p_price = $_POST['update_p_price'];

   
      $update_query = mysqli_query($conn, "UPDATE fangprices SET item_name = '$update_p_name', item_price = '$update_p_price' WHERE fangprices.item_ID = '$update_p_id';");
   
      if($update_query){
         
         $message[] = 'Item updated succesfully';
         header('location:AdminPricing.html.php');
      }else{
         $message[] = 'Item could not be updated';
         header('location:AdminPricing.html.php');
      }
   
   }
   

   
  
?>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="Styling/AdminStyle.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"
     integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A=="
      crossorigin="anonymous" referrerpolicy="no-referrer" /> 
    <title>Admin Item Manager</title>
</head>
<body>

<?php

if(isset($message)){
   foreach($message as $message){
      echo '<div class="message"><span>'.$message.'</span> <i class="fas fa-times" onclick="this.parentElement.style.display = `none`;"></i> </div>';
   }
}

?>
<header class="admin-header">

   <div class="flex">

        
            <img src="Images/fangtastic logo.jpeg" alt="Logo FANGJewlerz" class="circle-logo">
            <h4 class="company-name">FANGTASTIC™</h4>
        

      <nav class="navbar">
         <a href="Admin.html.php">Add Products</a>
         <a href="AdminPricing.html.php">Add Items</a>
      </nav>

      <a href="Cart.html.php" id="cartButton"><i class="fa-solid fa-cart-shopping" ></i><span>0</span></a>

      <a href="../FANGJewellerz Website/Components/logout.php" id="cartButton"><i class="fa-solid fa-right-from-bracket"></i></a>

      <div id="menu-btn" class="fas fa-bars"></div>

   </div>

</header>

   <div class="user-container">
      <div class="content">
         <h3>hi, <span>admin</span></h3>
         <h1>welcome, <span><?php echo $_SESSION["admin_user"];?></span></h1>
         <p>this is an admin pricing page</p>
         <a href="../FANGJewellerz Website/Components/logout.php">logout</a>
      </div>
   </div>   
    <!------------------------Admin Section------------------------->
    <div class="admin-container">
        <div class="admin-prod-form">
            <form action="<?php $_SERVER['PHP_SELF'] ?>" method="post" enctype="multipart/form-data">
                <h3>Add a New Item Listing</h3>
                <input type="text" placeholder="enter product name" name="product_name" class="box">
                <input type="number" placeholder="enter product price" name="product_price" class="box">
                <input type="submit" class="prod-btn" name="add_product" value="Add Product">
            </form>
        </div>
    </div>

    <?php

   $select = mysqli_query($conn, "SELECT * FROM fangprices;");
   
   ?>

   <section class="product-display-table">

   <table>

      <thead>
         <th>Item Name</th>
         <th>Item Price</th>
         <th>Action</th>
      </thead>

      <tbody>
         <?php
         
            $select_products = mysqli_query($conn, "SELECT * FROM fangprices;");
            if(mysqli_num_rows($select_products) > 0){
               while($row = mysqli_fetch_assoc($select_products)){
         ?>

         <tr>
            <td><?php echo $row['item_name']; ?></td>
            <td>R<?php echo $row['item_price']; ?>/-</td>
            <td>
               <a href="AdminPricing.html.php?delete=<?php echo $row['item_ID']; ?>" class="delete-btn" onclick="return confirm('are your sure you want to delete this item?');"> <i class="fas fa-trash"></i> delete </a>
               <a href="AdminPricing.html.php?edit=<?php echo $row['item_ID']; ?>" class="option-btn"> <i class="fas fa-edit"></i> update </a>
            </td>
         </tr>

         <?php
            };    
            }else{
               echo "<div class='empty'>no product added</div>";
            }; 
         ?>
      </tbody>
   </table>

</section>

<section class="edit-form-container">

   <?php
   
   if(isset($_GET['edit'])){
      $edit_id = $_GET['edit'];
      $edit_query = mysqli_query($conn, "SELECT * FROM fangprices WHERE item_ID = $edit_id");
      if(mysqli_num_rows($edit_query) > 0){
         while($fetch_edit = mysqli_fetch_assoc($edit_query)){
   ?>

   <form action="" method="post" enctype="multipart/form-data">
      <input type="hidden" name="update_p_id" value="<?php echo $fetch_edit['prod_ID']; ?>">
      <input type="text" class="box" required name="update_p_name" value="<?php echo $fetch_edit['prodName']; ?>">
      <input type="number" min="0" class="box" required name="update_p_price" value="<?php echo $fetch_edit['prodPrice']; ?>">
      <input type="submit" value="Update The Product" name="update_product" class="btn">
      <input type="reset" value="Cancel" id="close-edit" class="option-btn">
   </form>

   <?php
            };
         };
         echo "<script>document.querySelector('.edit-form-container').style.display = 'flex';</script>";
      };
   ?>

</section>



    <script src="JavaScrypt/Scrypt.js"></script>
</body>
</html>