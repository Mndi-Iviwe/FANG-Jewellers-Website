<?php
session_start();

@include 'Components/connection.php';
@include 'Components/alerts.php';


    if(isset($_POST['add_product'])){
    $product_name = (string)$_POST['product_name'];
    $product_price = (string)$_POST['product_price'];
    $product_image = $_FILES['product_image']['name'];
    $product_image_tmp_name = $_FILES['product_image']['tmp_name'];
    $product_image_folder = 'Product Images/'.$product_image;
 
    if(empty($product_name) || empty($product_price) || empty($product_image)){
       $message[] = 'Please fill out All details';
    }else{
            $istmt = $conn->prepare("INSERT INTO fangproducts (prodName, prodPrice, prodImage) VALUES (?, ?, ?);");
            // Bind parameters (string, double?, string)
            $istmt->bind_param("sds", $product_name, $product_price, $product_image);
            $istmt->execute();
            // Close the statement
            $istmt->close();
        if($istmt->execute()){
           move_uploaded_file($product_image_tmp_name, $product_image_folder);
           $message[] = 'New product added successfully';
        }else{
           $message[] = 'Could not add product';
        }
     }
   }

     

     if(isset($_GET['delete'])){
      $delete_id = $_GET['delete'];

      $dltstmt = $conn->prepare("DELETE FROM fangproducts WHERE fangproducts.prod_ID = ?");

      // Bind the parameter (assuming $id is an integer)
      $dltstmt->bind_param("i", $delete_id);

      // Execute the statement
      if($dltstmt->execute()){
         header('location:Admin.html.php');
         $message[] = 'product has been deleted';
      }else{
         header('location:Admin.html.php');
         $message[] = 'product could not be deleted';
      }

      // Close the statement
      $stmt->close();
   }

   if(isset($_POST['update_product'])){
      $update_p_id = $_POST['update_p_id'];
      $update_p_name = $_POST['update_p_name'];
      $update_p_price = $_POST['update_p_price'];
      $update_p_image = $_FILES['update_p_image']['name'];
      $update_p_image_tmp_name = $_FILES['update_p_image']['tmp_name'];
      $update_p_image_folder = 'Product Images/'.$update_p_image;
   
      $update_query = mysqli_query($conn, "UPDATE fangproducts SET prodName = '$update_p_name', prodPrice = '$update_p_price', prodImage = '$update_p_image' WHERE fangproducts.prod_ID = '$update_p_id';");
   
      if($update_query){
         
         move_uploaded_file($update_p_image_tmp_name, $update_p_image_folder);
         $message[] = 'product updated succesfully';
         header('location:Admin.html.php');
      }else{
         $message[] = 'product could not be updated';
         header('location:Admin.html.php');
      }
   
   }
   

   
  
?>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="Styling/AdminStyle.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"
     integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A=="
      crossorigin="anonymous" referrerpolicy="no-referrer" /> 
    <title>Admin Product Manager</title>
</head>
<body>

<?php

if(isset($message)){
   foreach($message as $message){
      echo '<div class="message"><span>'.$message.'</span> <i class="fas fa-times" onclick="this.parentElement.style.display = `none`;"></i> </div>';
   }
}

?>
<header class="admin-header">

   <div class="flex">

        
            <img src="Images/fangtastic logo.jpeg" alt="Logo FANGJewlerz" class="circle-logo">
            <h4 class="company-name">FANGTASTIC™</h4>
        

      <nav class="navbar">
         <a href="Admin.html.php">Add Products</a>
         <a href="AdminPricing.html.php">Add Items</a>
      </nav>

      <a href="Cart.html.php" id="cartButton"><i class="fa-solid fa-cart-shopping" ></i><span>0</span></a>

      <a href="../FANGJewellerz Website/Components/logout.php" id="cartButton"><i class="fa-solid fa-right-from-bracket"></i></a>

      <div id="menu-btn" class="fas fa-bars"></div>

   </div>

</header>

   <div class="user-container">
      <div class="content">
         <h3>hi, <span>admin</span></h3>
         <h1>welcome, <span><?php echo $_SESSION["admin_user"];?></span></h1>
         <p>this is an admin page</p>
         <a href="../FANGJewellerz Website/Components/logout.php">logout</a>
      </div>
   </div>   
    <!------------------------Admin Section------------------------->
    <div class="admin-container">
        <div class="admin-prod-form">
            <form action="<?php $_SERVER['PHP_SELF'] ?>" method="post" enctype="multipart/form-data">
                <h3>Add a New Product</h3>
                <input type="text" placeholder="enter product name" name="product_name" class="box">
                <input type="number" placeholder="enter product price" name="product_price" class="box">
                <input type="file" accept="image/png, image/jpeg, image/jpg" name="product_image" class="box">
                <input type="submit" class="prod-btn" name="add_product" value="Add Product">
            </form>
        </div>
    </div>

    <?php

   $select = mysqli_query($conn, "SELECT * FROM fangproducts;");
   
   ?>

   <section class="product-display-table">

   <table>

      <thead>
         <th>Product Image</th>
         <th>Product Name</th>
         <th>Product Price</th>
         <th>Action</th>
      </thead>

      <tbody>
         <?php
         
            $select_products = mysqli_query($conn, "SELECT * FROM fangproducts;");
            if(mysqli_num_rows($select_products) > 0){
               while($row = mysqli_fetch_assoc($select_products)){
         ?>

         <tr>
            <td><img src="Product Images/<?php echo $row['prodImage']; ?>" height="100" alt=""></td>
            <td><?php echo $row['prodName']; ?></td>
            <td>R<?php echo $row['prodPrice']; ?>/-</td>
            <td>
               <a href="Admin.html.php?delete=<?php echo $row['prod_ID']; ?>" class="delete-btn" onclick="return confirm('are your sure you want to delete this?');"> <i class="fas fa-trash"></i> delete </a>
               <a href="Admin.html.php?edit=<?php echo $row['prod_ID']; ?>" class="option-btn"> <i class="fas fa-edit"></i> update </a>
            </td>
         </tr>

         <?php
            };    
            }else{
               echo "<div class='empty'>no product added</div>";
            }; 
         ?>
      </tbody>
   </table>

</section>

<section class="edit-form-container">

   <?php
   
   if(isset($_GET['edit'])){
      $edit_id = $_GET['edit'];
      $edit_query = mysqli_query($conn, "SELECT * FROM fangproducts WHERE prod_ID = $edit_id");
      if(mysqli_num_rows($edit_query) > 0){
         while($fetch_edit = mysqli_fetch_assoc($edit_query)){
   ?>

   <form action="" method="post" enctype="multipart/form-data">
      <img src="Product Images/<?php echo $fetch_edit['prodImage']; ?>" height="200" alt="">
      <input type="hidden" name="update_p_id" value="<?php echo $fetch_edit['prod_ID']; ?>">
      <input type="text" class="box" required name="update_p_name" value="<?php echo $fetch_edit['prodName']; ?>">
      <input type="number" min="0" class="box" required name="update_p_price" value="<?php echo $fetch_edit['prodPrice']; ?>">
      <input type="file" class="box" required name="update_p_image" accept="image/png, image/jpg, image/jpeg">
      <input type="submit" value="Update The Product" name="update_product" class="btn">
      <input type="reset" value="Cancel" id="close-edit" class="option-btn">
   </form>

   <?php
            };
         };
         echo "<script>document.querySelector('.edit-form-container').style.display = 'flex';</script>";
      };
   ?>

</section>



    <script src="JavaScrypt/Scrypt.js"></script>
</body>
</html>