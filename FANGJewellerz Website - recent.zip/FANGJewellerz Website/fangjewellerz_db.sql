-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 03, 2024 at 07:17 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `fangjewellerz_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `fangadmin`
--

CREATE TABLE `fangadmin` (
  `admin_ID` int(255) NOT NULL,
  `adminFname` varchar(255) NOT NULL,
  `adminLname` varchar(255) NOT NULL,
  `adminEmail` varchar(50) NOT NULL,
  `adminPassword` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `fangcart`
--

CREATE TABLE `fangcart` (
  `cart_ID` int(255) NOT NULL,
  `c_prodname` varchar(255) NOT NULL,
  `c_prodprice` double NOT NULL,
  `c_prodimage` varchar(255) NOT NULL,
  `c_prodquant` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `fangorder`
--

CREATE TABLE `fangorder` (
  `order_ID` int(255) NOT NULL,
  `ord_prodname` varchar(255) NOT NULL,
  `ord_contact` varchar(10) NOT NULL,
  `ord_email` varchar(100) NOT NULL,
  `ord_method` varchar(100) NOT NULL,
  `ord_flat` varchar(255) NOT NULL,
  `ord_street` varchar(100) NOT NULL,
  `ord_province` varchar(50) NOT NULL,
  `ord_city` varchar(255) NOT NULL,
  `ord_totprods` int(255) NOT NULL,
  `ord_totprice` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `fangorder`
--

INSERT INTO `fangorder` (`order_ID`, `ord_prodname`, `ord_contact`, `ord_email`, `ord_method`, `ord_flat`, `ord_street`, `ord_province`, `ord_city`, `ord_totprods`, `ord_totprice`) VALUES
(1, 'dfgdfhrfhdsfh', 'fsdhdsfj', 'Mndiiviwe@gmail.com', 'cash on delivery', 'fgdjdfgjgjfj', 'gfjgdjfdjfgj', 'fgjfdgjjfgj', 'fgjgfj', 0, 899),
(2, 'dfgdfhrfhdsfh', 'fsdhdsfj', 'Mndiiviwe@gmail.com', 'cash on delivery', 'fgdjdfgjgjfj', 'gfjgdjfdjfgj', 'fgjfdgjjfgj', 'fgjgfj', 0, 899),
(3, 'dfgdfhrfhdsfh', 'fsdhdsfj', 'Mndiiviwe@gmail.com', 'cash on delivery', 'fgdjdfgjgjfj', 'gfjgdjfdjfgj', 'fgjfdgjjfgj', 'fgjgfj', 0, 899),
(4, 'dfgdfhrfhdsfh', 'fsdhdsfj', 'Mndiiviwe@gmail.com', 'cash on delivery', 'fgdjdfgjgjfj', 'gfjgdjfdjfgj', 'fgjfdgjjfgj', 'fgjgfj', 0, 899),
(5, 'dfgdfhrfhdsfh', 'fsdhdsfj', 'Mndiiviwe@gmail.com', 'cash on delivery', 'fgdjdfgjgjfj', 'gfjgdjfdjfgj', 'fgjfdgjjfgj', 'fgjgfj', 0, 899),
(6, 'dfgdfhrfhdsfh', 'fsdhdsfj', 'Mndiiviwe@gmail.com', 'cash on delivery', 'fgdjdfgjgjfj', 'gfjgdjfdjfgj', 'fgjfdgjjfgj', 'fgjgfj', 0, 899),
(7, 'dfgdfhrfhdsfh', 'fsdhdsfj', 'Mndiiviwe@gmail.com', 'cash on delivery', 'fgdjdfgjgjfj', 'gfjgdjfdjfgj', 'fgjfdgjjfgj', 'fgjgfj', 0, 899),
(8, 'dfgdfhrfhdsfh', 'fsdhdsfj', 'Mndiiviwe@gmail.com', 'cash on delivery', 'fgdjdfgjgjfj', 'gfjgdjfdjfgj', 'fgjfdgjjfgj', 'fgjgfj', 0, 899),
(9, 'dfgdfhrfhdsfh', 'fsdhdsfj', 'Mndiiviwe@gmail.com', 'cash on delivery', 'fgdjdfgjgjfj', 'gfjgdjfdjfgj', 'fgjfdgjjfgj', 'fgjgfj', 0, 899);

-- --------------------------------------------------------

--
-- Table structure for table `fangproducts`
--

CREATE TABLE `fangproducts` (
  `prod_ID` int(255) NOT NULL,
  `prodName` varchar(100) NOT NULL,
  `prodPrice` double NOT NULL,
  `prodImage` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `fangproducts`
--

INSERT INTO `fangproducts` (`prod_ID`, `prodName`, `prodPrice`, `prodImage`) VALUES
(4, 'House Tooth Gem Kit', 200, 'Toothgem-kit.jpg'),
(5, 'Gemzees: DIY TOOTH GEMS', 150, 'gem-kits.webp'),
(6, 'ICYBOSS: Tooth Gem Kit', 127, 'IMG-4362.webp'),
(9, 'DIY V Adorned Kit', 299, 'V\'adorned kit.jpeg');

-- --------------------------------------------------------

--
-- Table structure for table `fanguser`
--

CREATE TABLE `fanguser` (
  `fang_ID` int(255) NOT NULL,
  `Fname` varchar(50) NOT NULL,
  `Lname` varchar(50) NOT NULL,
  `fangEmail` varchar(50) NOT NULL,
  `fangPassword` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `fanguser`
--

INSERT INTO `fanguser` (`fang_ID`, `Fname`, `Lname`, `fangEmail`, `fangPassword`) VALUES
(1, 'Iviwe', 'Mndi', 'Mndiiviwe@gmail.com', '8bdcbb33f31a4747e330254ad878d994');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `fangadmin`
--
ALTER TABLE `fangadmin`
  ADD PRIMARY KEY (`admin_ID`);

--
-- Indexes for table `fangcart`
--
ALTER TABLE `fangcart`
  ADD PRIMARY KEY (`cart_ID`);

--
-- Indexes for table `fangorder`
--
ALTER TABLE `fangorder`
  ADD PRIMARY KEY (`order_ID`);

--
-- Indexes for table `fangproducts`
--
ALTER TABLE `fangproducts`
  ADD PRIMARY KEY (`prod_ID`);

--
-- Indexes for table `fanguser`
--
ALTER TABLE `fanguser`
  ADD PRIMARY KEY (`fang_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `fangadmin`
--
ALTER TABLE `fangadmin`
  MODIFY `admin_ID` int(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `fangcart`
--
ALTER TABLE `fangcart`
  MODIFY `cart_ID` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `fangorder`
--
ALTER TABLE `fangorder`
  MODIFY `order_ID` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `fangproducts`
--
ALTER TABLE `fangproducts`
  MODIFY `prod_ID` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `fanguser`
--
ALTER TABLE `fanguser`
  MODIFY `fang_ID` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
